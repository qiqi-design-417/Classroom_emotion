import React, { useState } from "react";
import "../assets/style/homeStyle.css"; // 样式文件
import '@fortawesome/fontawesome-free/css/all.min.css';


function HomePage() {
  const [uploadedVideo, setUploadedVideo] = useState(null); // 用户上传的视频
  const [processedVideo, setProcessedVideo] = useState(null); // 后端返回的处理后视频
  const [isLoading, setIsLoading] = useState(false); // 加载状态

  // 上传视频并预览
  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const videoURL = URL.createObjectURL(file); // 本地预览 URL
      setUploadedVideo(videoURL);
    }
  };

  // 发送视频到后端分析情绪
  const analyzeEmotion = async () => {
    if (!uploadedVideo) {
      alert("请先上传视频！");
      return;
    }

    setIsLoading(true);

    // 构造 FormData，包含上传的视频文件
    const formData = new FormData();
    formData.append("video", document.getElementById("fileInput").files[0]);

    try {
      // 调用后端 API
      const response = await fetch("http://localhost:5000/analyze", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("情绪分析失败，请重试！");
      }

      // 获取后端返回的处理后视频 URL
      const data = await response.json();
      setProcessedVideo(data.processedVideoUrl); // 假设后端返回字段为 processedVideoUrl
    } catch (error) {
      console.error(error);
      alert("发生错误：" + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>基于卷积神经网络的课堂情绪分析系统</h1>

      {/* 上传和播放视频部分 */}
      <div className="upload-section">
        <div id="file" className="file">
          {uploadedVideo ? (
            <video src={uploadedVideo} controls width="100%"></video>
          ) : (
            <i className="fa-solid fa-camera fa-5x"></i>
          )}
        </div>

        {/* 加载动画 */}
        {isLoading && (
          <div className="loading-message" id="analysisMessage">
            <p>正在进行分析...</p>
            <i className="fa-solid fa-spinner fa-spin fa-2xl"></i>
          </div>
        )}

        {/* 上传和分析按钮 */}
        <div className="file-actions">
          <input
            type="file"
            id="fileInput"
            accept=".mp4"
            onChange={handleFileUpload}
          />
          <button id="analyzeButton" onClick={analyzeEmotion} disabled={isLoading}>
            分析情绪
          </button>
        </div>
      </div>

      {/* 显示处理后的视频 */}
      {processedVideo && (
        <div className="processed-video">
          <h2>处理后的视频</h2>
          <video src={processedVideo} controls width="100%"></video>
        </div>
      )}
    </div>
  );
}

export default HomePage;

