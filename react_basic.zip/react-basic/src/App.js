// App.js
import React from 'react';
import Sidebar from './components/navbar';

const App = () => {
  return (
    <div className="App">
      <Sidebar />
    </div>
  );
};

export default App;



