import React from 'react';
import '../assets/style/sidebarStyle.css';
import 'boxicons/css/boxicons.min.css';
import tx from '../assets/image/Avatar.jpg';
import { Routes,Route, Link } from 'react-router-dom';
import Home from './homePage';

const Sidebar = () => {
  const handleArrowClick = (e) => {
    const arrowParent = e.currentTarget.parentElement.parentElement;
    arrowParent.classList.toggle("showMenu");
  };

  const toggleSidebar = () => {
    document.querySelector(".sidebar").classList.toggle("close");
  };

  return (
    <>
      <div className="sidebar">
        <div className="logo-details">
          <i className='bx bxl-c-plus-plus'></i>
          <span className="logo_name">课堂情绪分析系统</span>
        </div>

        <ul className="nav-links">
          <li>
            <Link to="/home" className="nav__link"> 
              <i className='bx bx-grid-alt'></i>
              <span className="link_name">首页</span>
            </Link> 
            <ul className="sub-menu blank">
              <li><Link to="/home" className="link_name nav__link">首页</Link></li>
            </ul> 
          </li>

          <li>
            <div className="iocn-link">
              <a href="#">
                <i className='bx bx-collection'></i>
                <span className="link_name">Category</span>
              </a>
              <i className='bx bxs-chevron-down arrow' onClick={handleArrowClick}></i>
            </div>
            <ul className="sub-menu">
              <li><a className="link_name" href="#">Category</a></li>
              <li><a href="#">HTML & CSS</a></li>
              <li><a href="#">JavaScript</a></li>
              <li><a href="#">PHP & MySQL</a></li>
            </ul>
          </li>
          
          {/* Posts with submenu */}
          <li>
            <div className="iocn-link">
              <a href="#">
                <i className='bx bx-book-alt'></i>
                <span className="link_name">Posts</span>
              </a>
              <i className='bx bxs-chevron-down arrow' onClick={handleArrowClick}></i>
            </div>
            <ul className="sub-menu">
              <li><a className="link_name" href="#">Posts</a></li>
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Login Form</a></li>
              <li><a href="#">Card Design</a></li>
            </ul>
          </li>

          {/* Analytics */}
          <li>
            <a href="#">
              <i className='bx bx-pie-chart-alt-2'></i>
              <span className="link_name">Analytics</span>
            </a>
            <ul className="sub-menu blank">
              <li><a className="link_name" href="#">Analytics</a></li>
            </ul>
          </li>

          {/* Chart */}
          <li>
            <a href="#">
              <i className='bx bx-line-chart'></i>
              <span className="link_name">Chart</span>
            </a>
            <ul className="sub-menu blank">
              <li><a className="link_name" href="#">Chart</a></li>
            </ul>
          </li>

          {/* Explore */}
          <li>
            <a href="#">
              <i className='bx bx-compass'></i>
              <span className="link_name">Explore</span>
            </a>
            <ul className="sub-menu blank">
              <li><a className="link_name" href="#">Explore</a></li>
            </ul>
          </li>

          {/* History */}
          <li>
            <a href="#">
              <i className='bx bx-history'></i>
              <span className="link_name">History</span>
            </a>
            <ul className="sub-menu blank">
              <li><a className="link_name" href="#">History</a></li>
            </ul>
          </li>

          {/* Setting */}
          <li>
            <a href="#">
              <i className='bx bx-cog'></i>
              <span className="link_name">Setting</span>
            </a>
            <ul className="sub-menu blank">
              <li><a className="link_name" href="#">Setting</a></li>
            </ul>
          </li>

          <li>
            <div className="profile-details">
              <div className="profile-content">
                <img src={tx} alt="profile" />
              </div>
              <div className="name-job">
                <div className="profile_name">荷塘月色</div>
                <div className="job">平平淡淡，简简单单！</div>
              </div>
              <i className='bx bx-log-out'></i>
            </div>
          </li>
        </ul>
      </div>

      <section className="home-section">
        <div className="home-content">
          <i className="bx bx-menu" onClick={toggleSidebar}></i>
          <span className="text">Drop Down Sidebar</span>
        </div>
        <div className="body-content">
          {/*实现路由跳转*/}
          <Routes>
            <Route path="/home" element={<Home />} />
          </Routes>
        </div>
      </section>
    </>
  );
};

export default Sidebar;

